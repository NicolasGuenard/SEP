/*******************************************************************************
  Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This file contains the "main" function for a project.

  Description:
    This file contains the "main" function for a project.  The
    "main" function calls the "SYS_Initialize" function to initialize the state
    machines of all modules in the system
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************
#include <stdio.h>
#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes


//Buffer UART
#define SIZE_TX_BUFFER 100
char TX_Buffer[SIZE_TX_BUFFER];
/*
//Fonction interruption Timer2
void HandlerTimer2(uint32_t status, uintptr_t context){
    
    ///////static uint8_t cmptUart=0;
    
    //TX_Buffer[0] = cmptUart++;      //Increment de la variable de test
    
    //Envoie d'une salve sur l'UART
    /////if(UART1_Write( (uint8_t*)TX_Buffer, 1 ))
    GPIO_PinToggle(GPIO_PIN_RB0);           //Toogle la LED
}
*/

//void UARTSend(uint8_t* pData, int length){
void UARTSend(char* Text){    
    
//    TX_Buffer[0]='H';
//    TX_Buffer[1]='K';    
  ////  UART1_Write( pData, length );
    //sprintf(TX_Buffer,"Test de la fonction \r\n");
    sprintf(TX_Buffer,Text);    
    UART1_Write( TX_Buffer, 30 );    

}

void CaractereSend(uint8_t Text){  
    //sprintf(TX_Buffer,"%s /r /n",Text);    
    UART1_Write( &Text, 1); 

}

// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************

int main ( void )
{
    /* Initialize all modules */
    SYS_Initialize ( NULL );

    //Initialisation de l'UART
    UART1_Initialize();
    
    //Lancement du timer 2
  /*  TMR2_Initialize();
    TMR2_CallbackRegister(HandlerTimer2,0);
    TMR2_InterruptEnable();
    TMR2_Start();
    */
    UARTSend("Lancement du soft! \r\n");
    
    while ( true )
    {
        /* Maintain state machines of all polled MPLAB Harmony modules. */
        SYS_Tasks ( );
    }

    /* Execution should not come here during normal operation */

    return ( EXIT_FAILURE );
}


/*******************************************************************************
 End of File
*/

