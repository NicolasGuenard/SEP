/*******************************************************************************
  MPLAB Harmony Application Source File

  Company:
    Microchip Technology Inc.

  File Name:
    app.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It
    implements the logic of the application's state machine and it may call
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include "app.h"

#include <string.h>

#define LED_ON() GPIO_PinClear(GPIO_PIN_RB0)
#define LED_OFF() GPIO_PinSet(GPIO_PIN_RB0)

void UARTSend(char* Text);
void CaractereSend(uint8_t Text);

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************
/* Usage ID to Key map table */
/*
const char *keyValue[] = { 
                          "No event indicated",
                          "ErrorRoll Over",
                          "POSTFail",
                          "Error Undefined",
                          "a",  
                          "b",
                          "c",
                          "d",
                          "e",
                          "f",
                          "g",
                          "h",
                          "i",
                          "j",
                          "k",
                          "l",
                          "m",
                          "n",
                          "o",
                          "p",
                          "q",  
                          "r",
                          "s",
                          "t",
                          "u",
                          "v",
                          "w",
                          "x",
                          "y",
                          "z",
                          "1",
                          "2",
                          "3",
                          "4",
                          "5",
                          "6",
                          "7",
                          "8",
                          "9",
                          "0",
                          "ENTER",
                          "ESCAPE",
                          "BACKSPACE",
                          "TAB",
                          "SPACEBAR",
                          "-",
                          "=",
                          "[",
                          "]",
                          "\\0",
                          "~",
                          ";",
                          "'",
                          "GRAVE ACCENT",
                          ",",
                          ".",
                          "/",
                          "CAPS LOCK",
                          "F1",
                          "F2",
                          "F3",
                          "F4",
                          "F5",
                          "F6",
                          "F7",
                          "F8",
                          "F9",
                          "F10",
                          "F11",
                          "F12",
                          "",   //indetermine
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",                          
                          "",
                          "1",
                          "2",
                          "3",
                          "4",
                          "5",
                          "6",
                          "7",
                          "8",
                          "9",
                          "0"                          
                      
                      };
*/

const char *keyValue_minuscule[] = { 
                          "No event indicated",
                          "ErrorRoll Over",
                          "POSTFail",
                          "Error Undefined",
                          "q",  
                          "b",
                          "c",
                          "d",
                          "e",
                          "f",
                          "g",
                          "h",
                          "i",
                          "j",
                          "k",
                          "l",
                          ",",
                          "n",
                          "o",
                          "p",
                          "a",  
                          "r",
                          "s",
                          "t",
                          "u",
                          "v",
                          "z",
                          "x",
                          "y",
                          "w",
                          "&",
                          "�",
                          """",
                          "'",
                          "(",
                          "-",
                          "�",
                          "_",
                          "�",
                          "�",
                          "ENTER",
                          "ESCAPE",
                          "BACKSPACE",
                          "TAB",
                          "SPACEBAR",
                          ")",
                          "=",
                          "^",
                          "$",
                          "\\0",
                          "*",
                          "m",
                          "�",
                          "GRAVE ACCENT",
                          ";",
                          ":",
                          "!",
                          "CAPS LOCK",
                          "F1",
                          "F2",
                          "F3",
                          "F4",
                          "F5",
                          "F6",
                          "F7",
                          "F8",
                          "F9",
                          "F10",
                          "F11",
                          "F12",
                          "",   //indetermine
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                          "/",
                          "*",
                          "-",
                          "+",                          
                          "ENTER",
                          "1",
                          "2",
                          "3",
                          "4",
                          "5",
                          "6",
                          "7",
                          "8",
                          "9",
                          "0"                          
                      };

const char *keyValue_MAJUSCULE[] = { 
                          "No event indicated",
                          "ErrorRoll Over",
                          "POSTFail",
                          "Error Undefined",
                          "Q",  
                          "B",
                          "C",
                          "D",
                          "E",
                          "F",
                          "G",
                          "H",
                          "I",
                          "J",
                          "K",
                          "L",
                          "?",
                          "N",
                          "O",
                          "P",
                          "A",  
                          "R",
                          "S",
                          "T",
                          "U",
                          "V",
                          "Z",
                          "X",
                          "Y",
                          "W",
                          "1",
                          "2",
                          "3",
                          "4",
                          "5",
                          "6",
                          "7",
                          "8",
                          "9",
                          "0",
                          "ENTER",
                          "ESCAPE",
                          "BACKSPACE",
                          "TAB",
                          "SPACEBAR",
                          "�",
                          "+",
                          "�",
                          "�",
                          "\\0",
                          "�",
                          "M",
                          "%",
                          "GRAVE ACCENT",
                          ".",
                          "/",
                          "�",
                          "CAPS LOCK",
                          "F1",
                          "F2",
                          "F3",
                          "F4",
                          "F5",
                          "F6",
                          "F7",
                          "F8",
                          "F9",
                          "F10",
                          "F11",
                          "F12",
                          "",   //indetermine
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                          "/",
                          "*",
                          "-",
                          "+",                          
                          "ENTER",
                          "1",
                          "2",
                          "3",
                          "4",
                          "5",
                          "6",
                          "7",
                          "8",
                          "9",
                          "0"                          
                      };

// *****************************************************************************
/* Application Data

  Summary:
    Holds application data

  Description:
    This structure holds the application's data.

  Remarks:
    This structure should be initialized by the APP_Initialize function.

    Application strings and buffers are be defined outside this structure.
*/

APP_DATA appData;

// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************


/*******************************************************
 * USB HOST Layer Events - Host Event Handler
 *******************************************************/

USB_HOST_EVENT_RESPONSE APP_USBHostEventHandler (USB_HOST_EVENT event, void * eventData, uintptr_t context)
{
    switch(event)
    {
        case USB_HOST_EVENT_DEVICE_UNSUPPORTED:
            UARTSend("Unsupprted... \r\n");
            break;
        default:
            break;
    }
    return USB_HOST_EVENT_RESPONSE_NONE;
}

/*******************************************************
 * USB HOST HID Layer Events - Application Event Handler
 *******************************************************/

void APP_USBHostHIDKeyboardEventHandler(USB_HOST_HID_KEYBOARD_HANDLE handle, 
        USB_HOST_HID_KEYBOARD_EVENT event, void * pData)
{   
    switch ( event)
    {
        case USB_HOST_HID_KEYBOARD_EVENT_ATTACH:
            appData.handle = handle;
            appData.state =  APP_STATE_DEVICE_ATTACHED;
            appData.nBytesWritten = 0;
            appData.stringReady = false;
            memset(&appData.string, 0, sizeof(appData.string));
            memset(&appData.lastData, 0, sizeof(appData.lastData));
            appData.stringSize = 0;
            appData.capsLockPressed = false;
            appData.scrollLockPressed = false;
            appData.numLockPressed = false;
            appData.outputReport = 0;
	////////////////		LED1_On();
            LED_OFF();
            UARTSend("ATTACHED \r\n");
            break;

        case USB_HOST_HID_KEYBOARD_EVENT_DETACH:
            appData.handle = handle;
            appData.state = APP_STATE_DEVICE_DETACHED;
            appData.nBytesWritten = 0;
            appData.stringReady = false;
            appData.usartTaskState = APP_USART_STATE_CHECK_FOR_STRING_TO_SEND;
            memset(&appData.string, 0, sizeof(appData.string));
            memset(&appData.lastData, 0, sizeof(appData.lastData));
            appData.stringSize = 0;
            appData.capsLockPressed = false;
            appData.scrollLockPressed = false;
            appData.numLockPressed = false;
            appData.outputReport = 0;
	/////////////////		LED1_Off();
            LED_ON();
            UARTSend("DETACHED \r\n");
            break;

        case USB_HOST_HID_KEYBOARD_EVENT_REPORT_RECEIVED:
            appData.handle = handle;
            appData.state = APP_STATE_READ_HID;
            /* Keyboard Data from device */
            memcpy(&appData.data, pData, sizeof(appData.data));
            ////////UARTSend("Detection!!!!!!!!... \r\n");
            LED_OFF();
            break;

        default:
            break;
    }
    return;
}

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************
/*
 * 
 * 
 void APP_MapKeyToUsage(USB_HID_KEYBOARD_KEYPAD keyCode)
{
    uint8_t outputReport = 0;
    
    outputReport = appData.outputReport;
    
    //CaractereSend(keyCode);
    
    if((keyCode >= USB_HID_KEYBOARD_KEYPAD_KEYBOARD_A &&
            keyCode <= USB_HID_KEYBOARD_KEYPAD_KEYBOARD_PRINT_SCREEN) ||            //USB_HID_KEYBOARD_KEYPAD_KEYBOARD_0_AND_CLOSE_PARENTHESIS
            (keyCode == USB_HID_KEYBOARD_KEYPAD_KEYBOARD_CAPS_LOCK) || 
            (keyCode == USB_HID_KEYBOARD_KEYPAD_KEYBOARD_SCROLL_LOCK) ||            
            (keyCode == USB_HID_KEYBOARD_KEYPAD_KEYPAD_NUM_LOCK_AND_CLEAR))         
    {
        if(keyCode >= USB_HID_KEYBOARD_KEYPAD_KEYBOARD_A &&
            keyCode <= USB_HID_KEYBOARD_KEYPAD_KEYBOARD_PRINT_SCREEN)               //USB_HID_KEYBOARD_KEYPAD_KEYBOARD_0_AND_CLOSE_PARENTHESIS
        {
            memcpy(&appData.string[appData.currentOffset], keyValue[keyCode],
                            strlen(keyValue[keyCode]));
        }
        else
        {
            if(keyCode == USB_HID_KEYBOARD_KEYPAD_KEYBOARD_CAPS_LOCK)
            {
                // CAPS LOCK pressed 
                if(appData.capsLockPressed == false)
                {
                    appData.capsLockPressed = true;
                    outputReport = outputReport | 0x2;
                }
                else
                {
                    appData.capsLockPressed = false;
                    outputReport = outputReport & 0xFD;
                }
            }
            if(keyCode == USB_HID_KEYBOARD_KEYPAD_KEYBOARD_SCROLL_LOCK)
            {
                // SCROLL LOCK pressed 
                if(appData.scrollLockPressed == false)
                {
                    appData.scrollLockPressed = true;
                    outputReport = outputReport | 0x4;
                }
                else
                {
                    appData.scrollLockPressed = false;
                    outputReport = outputReport & 0xFB;
                }
            }
            if(keyCode == USB_HID_KEYBOARD_KEYPAD_KEYPAD_NUM_LOCK_AND_CLEAR)
            {
                // NUM LOCK pressed 
                if(appData.numLockPressed == false)
                {
                    appData.numLockPressed = true;
                    outputReport = outputReport | 0x1;
                }
                else
                {
                    appData.numLockPressed = false;
                    outputReport = outputReport & 0xFE;
                }
            }
            
            // Store the changes 
            appData.outputReport = outputReport;
            // Send the OUTPUT Report 
            USB_HOST_HID_KEYBOARD_ReportSend(appData.handle, outputReport);
        }
        if(appData.capsLockPressed && (appData.data.modifierKeysData.leftShift ||
                appData.data.modifierKeysData.rightShift))
        {
            // Small case should be displayed 
        }
        // Check if it is within a - z 
        else if((appData.capsLockPressed || appData.data.modifierKeysData.leftShift ||
                appData.data.modifierKeysData.rightShift) &&
                (keyCode >= USB_HID_KEYBOARD_KEYPAD_KEYBOARD_A &&
                keyCode <= USB_HID_KEYBOARD_KEYPAD_KEYBOARD_Z))
        {
            appData.string[appData.currentOffset] = appData.string[appData.currentOffset] - 32;
        }        
        appData.currentOffset = appData.currentOffset + sizeof(keyValue[keyCode]);
    }
    //char m_char=ConvertQWERTY_2_AZERTY((char)(appData.string[0]));
    

    ///////CaractereSend(m_char);
    //CaractereSend((char)(appData.string[0]));
    CaractereSend(keyCode);
}
 * 
 * */
void APP_MapKeyToUsage(USB_HID_KEYBOARD_KEYPAD keyCode)
{
    uint8_t outputReport = 0;
    
    outputReport = appData.outputReport;
    
    
    if(keyCode>0 && keyCode<99){    //Zone renseign�e
    
        //Traitement de l'enclenchement de la majuscule
        if(keyCode == USB_HID_KEYBOARD_KEYPAD_KEYBOARD_CAPS_LOCK)
        {
            /* CAPS LOCK pressed */
            if(appData.capsLockPressed == false)
            {
                appData.capsLockPressed = true;
                outputReport = outputReport | 0x2;
            }
            else
            {
                appData.capsLockPressed = false;
                outputReport = outputReport & 0xFD;
            }
        }
        else if(keyCode == USB_HID_KEYBOARD_KEYPAD_KEYBOARD_SCROLL_LOCK)
        {
            /* SCROLL LOCK pressed */
            if(appData.scrollLockPressed == false)
            {
                appData.scrollLockPressed = true;
                outputReport = outputReport | 0x4;
            }
            else
            {
                appData.scrollLockPressed = false;
                outputReport = outputReport & 0xFB;
            }
        }
        else if(keyCode == USB_HID_KEYBOARD_KEYPAD_KEYPAD_NUM_LOCK_AND_CLEAR)
        {
            /* NUM LOCK pressed */
            if(appData.numLockPressed == false)
            {
                appData.numLockPressed = true;
                outputReport = outputReport | 0x1;
            }
            else
            {
                appData.numLockPressed = false;
                outputReport = outputReport & 0xFE;
            }
        }

        /* Store the changes */
        appData.outputReport = outputReport;
        /* Send the OUTPUT Report */
        USB_HOST_HID_KEYBOARD_ReportSend(appData.handle, outputReport);

        //Traitement de la touche sur laquelle on appuie   
        if((appData.capsLockPressed || appData.data.modifierKeysData.leftShift ||
                    appData.data.modifierKeysData.rightShift))
        {
            //Mode MAJUSCULE
            memcpy(&appData.string[appData.currentOffset], keyValue_MAJUSCULE[keyCode],
                            strlen(keyValue_MAJUSCULE[keyCode]));
            appData.currentOffset = appData.currentOffset + sizeof(keyValue_MAJUSCULE[keyCode]);
        }else{
            //Mode minuscule
             memcpy(&appData.string[appData.currentOffset], keyValue_minuscule[keyCode],
                            strlen(keyValue_minuscule[keyCode]));       
             appData.currentOffset = appData.currentOffset + sizeof(keyValue_minuscule[keyCode]);

        }

        ///////CaractereSend(m_char);

        CaractereSend((char)(appData.string[0]));
        //CaractereSend(keyCode);
    }
}


// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void APP_Initialize ( void )

  Remarks:
    See prototype in app.h.
 */

void APP_Initialize ( void )
{
    /* Place the App state machine in its initial state. */
    memset(&appData, 0, sizeof(appData));
    appData.state = APP_STATE_INIT;
    //appData.usartTaskState = APP_USART_STATE_DRIVER_OPEN;
    //appData.WriteBufHandler = DRV_USART_BUFFER_HANDLE_INVALID;
    
}


void APP_USART_Tasks(void)
{
  /**  
    switch(appData.usartTaskState)
    {
        case APP_USART_STATE_DRIVER_OPEN:
            
            // Try to open the USART driver 
            appData.usartDriverHandle = DRV_USART_Open(DRV_USART_INDEX_0,
                    DRV_IO_INTENT_READWRITE | DRV_IO_INTENT_NONBLOCKING);
            if(appData.usartDriverHandle != DRV_HANDLE_INVALID)
            {
                // The driver could be opened. We should be able to send data 
                appData.usartTaskState = APP_USART_STATE_CHECK_FOR_STRING_TO_SEND;
            }
            break;
            
        case APP_USART_STATE_CHECK_FOR_STRING_TO_SEND:
            
            // In this state we check if the there is string to be transmitted 
            if(appData.stringReady)
            {
                // Write the string to the driver 
                appData.usartTaskState = APP_USART_STATE_DRIVER_WRITE;
                appData.nBytesWritten = 0;
            }
            
            break;
            
        case APP_USART_STATE_DRIVER_WRITE:
 */           
            /* Write the string to the driver. We will need to check how much
             * of the string was actually written and update the pointer and
             * size accordingly */
  /*         DRV_USART_WriteBufferAdd(appData.usartDriverHandle, 
                    appData.string , sizeof( appData.string ), &appData.WriteBufHandler );
            
             appData.stringReady = false;
            appData.usartTaskState = APP_USART_STATE_CHECK_FOR_STRING_TO_SEND;
        break;
            
        default:
            break;
    }*/
}

/******************************************************************************
  Function:
    void APP_Tasks ( void )

  Remarks:
    See prototype in app.h.
 */

void APP_Tasks ( void )
{
    uint64_t sysCount = 0;
    uint8_t count = 0;
    uint8_t counter = 0;
    bool foundInLast = false;
    
    appData.currentOffset = 0;
    
    /* Check the application's current state. */
    switch ( appData.state )
    {
        /* Application's initial state. */
        case APP_STATE_INIT:
            USB_HOST_EventHandlerSet(APP_USBHostEventHandler, 0);
            USB_HOST_HID_KEYBOARD_EventHandlerSet(APP_USBHostHIDKeyboardEventHandler);
            
			USB_HOST_BusEnable(USB_HOST_BUS_ALL);
			appData.state = APP_STATE_WAIT_FOR_HOST_ENABLE;
            break;
			
		case APP_STATE_WAIT_FOR_HOST_ENABLE:
            /* Check if the host operation has been enabled */
            if(USB_HOST_BusIsEnabled(USB_HOST_BUS_ALL))
            {
                /* This means host operation is enabled. We can
                 * move on to the next state */
                appData.state = APP_STATE_HOST_ENABLE_DONE;
            }
            break;
        case APP_STATE_HOST_ENABLE_DONE:
            appData.stringSize = 64;
            if(appData.usartTaskState == APP_USART_STATE_CHECK_FOR_STRING_TO_SEND)
            {
                memcpy(&appData.string[0], "\r\n***Connect Keyboard***\r\n",
                            sizeof("\r\n***Connect Keyboard***\r\n"));
                appData.stringReady = true;
               ///////// UARTSend("WA", 2);
                /* The test was successful. Lets idle. */
                appData.state = APP_STATE_WAIT_FOR_DEVICE_ATTACH;
                
            }
            break;

        case APP_STATE_WAIT_FOR_DEVICE_ATTACH:

            /* Wait for device attach. The state machine will move
             * to the next state when the attach event
             * is received.  */

            /*     memcpy(&appData.string[0], "\r\n***wait for device attached***\r\n",
                sizeof("\r\n***wait for device attached***\r\n"));             
                 appData.stringReady = true;
            */     
                //////////appData.state = APP_STATE_DEVICE_ATTACHED;
            
            break;

        case APP_STATE_DEVICE_ATTACHED:
  
             /*    memcpy(&appData.string[0], "\r\n***Device attached!!***\r\n",
                sizeof("\r\n***Device attached!!***\r\n"));             
                 appData.stringReady = true;      */      
            
            /* Wait for device report */
            if(appData.usartTaskState == APP_USART_STATE_CHECK_FOR_STRING_TO_SEND)
            {
                memcpy(&appData.string[0], "---Keyboard Connected---\r\n",
                        sizeof("---Keyboard Connected---\r\n"));
                /////UARTSend("CO", 2);
                appData.stringReady = true;
                appData.stringSize = 64;
                appData.state = APP_STATE_READ_HID;
            }
            break;

        case APP_STATE_READ_HID:
            
            
            
            //if(appData.usartTaskState == APP_USART_STATE_CHECK_FOR_STRING_TO_SEND)
            if(1)    
            {
                //UARTSend("REad HID!!!!!!!!... \r\n");
                
                /* We need to display only the non modifier keys */
                for(count = 0; count < 6; count++)
                {
                    if(appData.data.nonModifierKeysData[count].event == USB_HID_KEY_PRESSED)
                    {
                        
                        appData.stringReady = false;
                        /* We can send Data to USART but need to check*/
                        appData.stringSize = 64;
                        memset(&appData.string, 0, sizeof(appData.string));
                        for(counter = 0; counter < 6; counter++)
                        {
                            if((appData.lastData.data.nonModifierKeysData[counter].event == USB_HID_KEY_PRESSED)
                                &&((appData.lastData.data.nonModifierKeysData[counter].keyCode == 
                                    appData.data.nonModifierKeysData[count].keyCode)))
                            {
                                
                                sysCount = SYS_TIME_CounterGet ();
                                if(500 <= 1000 *            //200
                                        (sysCount - appData.lastData.data.nonModifierKeysData[counter].sysCount)
                                        / SYS_TIME_FrequencyGet())
                                {
                                    foundInLast = false;
                                    
                                }
                                else
                                {
                                    foundInLast = true;
                                    
                                }
                                break;
                            }
                        }
                        if(foundInLast == false)
                        {
                            appData.stringReady = true;
                            APP_MapKeyToUsage(appData.data.nonModifierKeysData[count].keyCode);
                        }
                        else
                        {
                            /* Reset it it false for next iteration */
                            foundInLast = false;
                        }
                    }
                }
                /* Store the present to future */
                memcpy(&appData.lastData.data, &appData.data, sizeof(appData.data));
            }
            break;

        case APP_STATE_DEVICE_DETACHED:
            appData.state = APP_STATE_HOST_ENABLE_DONE;
            break;

        case APP_STATE_ERROR:

            /* The application comes here when the demo
             * has failed. Provide LED indication .*/

            
            break;

        default:
            break;
    }
    /* Call the USART task routine */
    ///////////////////////////////APP_USART_Tasks();
}


/*******************************************************************************
 End of File
 */
